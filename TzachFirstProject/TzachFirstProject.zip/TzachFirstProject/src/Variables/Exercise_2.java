package Variables;

public class Exercise_2 {

	public static void main(String[] args) {
		System.out.println("Section 1:");
		int age = 23;
		System.out.println(age);
		age+= 5; // age = age + 5;
		System.out.println(age);
		
		System.out.println("Section 2:");
		age = 23;
		age *= 3;
		System.out.println(age);
	}

}
