package Variables;

public class Exercise_5 {

	public static void main(String[] args) {
		System.out.println("The first answer wiil be 120 , The second answer will be 102");

		int a = 18;
		int b = 42;
		int first = (a + b) * 2;
		int second = a + b * 2;
		System.out.println("first number is: " + first);
		System.out.println("first number is: " + second);

	}

}
