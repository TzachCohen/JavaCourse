package Variables;

public class Exercise_4 {

	public static void main(String[] args) {
		System.out.println("Section 1: will make calculation");
		System.out.println(3 + 4 + 5);
		
		System.out.println("Section 2: will make String");
		System.out.println("3 + 4 + 5");

	}

}
