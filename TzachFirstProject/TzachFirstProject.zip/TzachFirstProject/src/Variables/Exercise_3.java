package Variables;

public class Exercise_3 {

	public static void main(String[] args) {
		
		System.out.println("Section 1:");
		int childAge = 7;
		System.out.println(childAge);
		
		System.out.println("Section 2:");
		double employeeSalary = 13465; // אפשר גם עם - long
		System.out.println(employeeSalary);
		
		System.out.println("Section 3:");
		boolean have_A_Dog = true; 
		System.out.println(have_A_Dog);
		
		System.out.println("Section 4:");
		String firstName = "Naveh";
		System.out.println(firstName);
		
		
		
		
		
	}

}
