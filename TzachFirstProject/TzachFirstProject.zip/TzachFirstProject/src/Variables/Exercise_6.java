package Variables;

public class Exercise_6 {

	public static void main(String[] args) {
		
		System.out.println("Section 1:");
		long number = 10;
		System.out.println(number);
		
		System.out.println("Section 2:");
		number = number + 20;    // number += 20;
		System.out.println(number);
		
		System.out.println("Section 3:");
		number = 10;
		number /= 2;    // number = number / 3; 
		System.out.println(number);
		
		System.out.println("Section 4:");
		number = 10;
		number *= 4;
		System.out.println(number);
		
		
	}

}
